
###############################################################
# Extreme and non-extreme BHEP multivariate test statistics
# h = smoothing parameter
# Mahalanobis = Mahalanobis distances and angles = D_ij
# n = sample size
# d = data-dimension

BHEP.infty = function(Mahalanobis,n,d)
    { 
      M.distances <- diag(Mahalanobis)
      b1 <- sum(Mahalanobis^3)/n^2
      b1t <- t(M.distances)%*%Mahalanobis%*%M.distances/n^2
      Tn0 <- b1/6 + b1t/4
      ##as.real(n*Tn0) #changed by RM
      as.double(n*Tn0)
    }

BHEP.zero = function(Mahalanobis,n,d)
    {
      Tninfty <- mean(exp(-diag(Mahalanobis)/2))
      sqrt(n)*abs(Tninfty - 2^(-d/2))
    }

BHEP.stat = function(h,Mahalanobis,n,d) #corrected value
    {
      M.distances <- diag(Mahalanobis)
      A <- matrix(rep(M.distances,n),ncol=n)
      M.differences <- A + t(A) - 2*Mahalanobis  #=D_ii-2D_ij+D_jj=||Y_i - Y_j||^2
      h1 <- 2*h^2
      h2 <- 2*h^2+1
      h3 <- 2*h^2+2
      term1 <- 2*sum(exp(-M.differences[upper.tri(M.differences)]/(2*h1)))/(n*h1^(d/2))
      term2 <- 2*sum(exp(-M.distances/(2*h2)))/(h2^(d/2))
      bhep <- (2*pi)^(d/2)*( term1 - term2 + h1^(-d/2) + n*h3^(-d/2) )
      bhep
    }

###################################################################
# Multiple test P-value evaluation
# y = observed sample

p.value.BB = function(y)
    {
     #sample size
     n <- length(y[,1])
     if (n<20) warning("sample size must be >= 20") 
     else {
      
     #data dimension
     d <- length(y[1,])
     if ((d==1)||(d>10)) warning("data dimension is not between 2 and 10") 
     else {
     
     #considered set of sizes
     alphas <- c(seq(0.0005,0.15,by=0.0005),seq(0.15+0.05,0.95,by=0.05))
     lalphas <- length(alphas)
     
     #considered set of sample sizes 
     ns <- c(seq(20,100,by=5),seq(110,200,by=10),seq(220,300,by=20),seq(350,800,by=50),900,1000)
     lns <- length(ns)

     line <- length(ns[ns<=n])
     n.close <- ns[line]

     if ((n.close==n)||(n>1000)) 
      {
       corr1 <- as.matrix(read.table("BZ_BB.R",skip=(d-2)*lns+line-1,nrows=1))
       corr2 <- as.matrix(read.table("BI_BB.R",skip=(d-2)*lns+line-1,nrows=1))
       corr3 <- as.matrix(read.table("BS_BB.R",skip=(d-2)*lns+line-1,nrows=1))
       corr4 <- as.matrix(read.table("BL_BB.R",skip=(d-2)*lns+line-1,nrows=1))
      }

     if ((n.close<n)&(n<=1000)) 
      {
       distanc<-(n-ns[line])/(ns[line+1]-ns[line]) #weighted distance between n and n.close
       corr1o <- as.matrix(read.table("BZ_BB.R",skip=(d-2)*lns+line-1,nrows=2)) 
       corr2o <- as.matrix(read.table("BI_BB.R",skip=(d-2)*lns+line-1,nrows=2))
       corr3o <- as.matrix(read.table("BS_BB.R",skip=(d-2)*lns+line-1,nrows=2))
       corr4o <- as.matrix(read.table("BL_BB.R",skip=(d-2)*lns+line-1,nrows=2))
       corr1 <- (1-distanc)*corr1o[1,]+distanc*corr1o[2,]
       corr2 <- (1-distanc)*corr2o[1,]+distanc*corr2o[2,]
       corr3 <- (1-distanc)*corr3o[1,]+distanc*corr3o[2,]
       corr4 <- (1-distanc)*corr4o[1,]+distanc*corr4o[2,]
      }

     #Test statistic evaluation
     Tn <- array(dim=c(lalphas))
     invS <- solve((1-1/n)*cov(y))
     med <- matrix(rep(colMeans(y),n),ncol=d,byrow=TRUE)
     Mahalanobis <- (y-med)%*%invS%*%t(y-med)
     s2 <- 3^(-d/2)-2^(-d)-d*2^(-d-3)
     
         Tn.a<-array(dim=c(4,lalphas))
         Tn.a[1,] <- BHEP.zero(Mahalanobis,n,d)^2/s2 - corr1
         Tn.a[2,] <- BHEP.infty(Mahalanobis,n,d) - corr2
         
         Tn.a[3,] <- BHEP.stat(0.448 + 0.026*d,Mahalanobis,n,d) - corr3
         Tn.a[4,] <- BHEP.stat(0.928 + 0.049*d,Mahalanobis,n,d) - corr4
         Tn <- apply(Tn.a,MARGIN=2,FUN=max)

     comp <- length(Tn[Tn<=0])

     if ((comp==0)|(comp==1)) pv <- paste("p-value <",alphas[1]) else
     if (comp==lalphas) pv <- paste("p-value >=",alphas[comp]) else 
     pv <- paste(alphas[comp],"< p-value <",alphas[comp+1])

     pv
     
     }}
    }
    
