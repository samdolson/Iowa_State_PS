

The function p.value.BB(y) (see the file  pvalueBB_evaluation.R), where y (array of n lines and d columns) is a sample of size n (n \geq 20) over R^d (2\leq d \leq 10), gives an approximation for the P-value of the multiple test procedure BB proposed in

C. Tenreiro (2014). A new test for multivariate normality by combining extreme and non-extreme BHEP tests.
Accepted for publication in Communications in Statistics - Simulation and Computation.
(Author's version of the paper, November 2014: http://www.mat.uc.pt/~tenreiro/publications/cene-authorversion.pdf)

This approximation is based on Monte Carlo estimates of the quantiles c_{n,h}(u_{n,\alpha}) for each one of the involved multivariate test statistics where we take n \in { 20, (5), 100, 110, (10), 200, 220, (20), 300, (50), 800, 900, 1000 } and \alpha varying on the grid { 0.0005, (0.0005), 0.15, 0.2, (0.05), 0.95 }.

50,000 simulations under the null hypothesis and the R function quantile(,type=7) were used for estimating the quantiles c_{n,h}(u) for u varying on a regular grid of size 0.0001 on the interval ]0,1[, and further 50,000 simulations were used for estimating the probabilities P_\phi(T_n(u)>0).

The quantile estimates c_{n,h}(u_{n,\alpha}) are in the files BZ_BB.R, BI_BB.R, BS_BB.R, BL_BB.R. For sample sizes different from the previous ones with n < 1000 the P-value is obtained by interpolation. For n > 1000 the P-value approximation is based on the quantiles for n = 1000.


EXAMPLE

R functions needed (see file pvalueBB_evaluation.R):

BHEP.stat
BHEP.infty
BHEP.zero
p.value.BB

source("pvalueBB_evaluation.R")


library(MASS)

### Mixture of two multivariate normal distributions ###

mvrnormixt = function(n,d,p,mu1,rho1,mu2,rho2)
{
 mean1 <- rep(mu1,d)
 covar1 <- matrix(rep(rho1,d^2),ncol=d,nrow=d)+diag(rep(1-rho1,d))
 mean2 <- rep(mu2,d)
 covar2 <- matrix(rep(rho2,d^2),ncol=d,nrow=d)+diag(rep(1-rho2,d))
 x1 <- mvrnorm(n,mean1,covar1)
 x2 <- mvrnorm(n,mean2,covar2)
 pp <- 1*(runif(n)<p)
 return(pp*x1+(1-pp)*x2)
}


### Data dimension and Sample size ###

d = 10
n = 30


### Standard normal distribution sample ###

y <- mvrnorm(n,rep(0,d),diag(1,nrow=d,ncol=d))

p.value.BB(y)

### Normal scale mixture p*N(0,B) + (1-p)*N(0,I) sample ###
### where B is a correlation matrix with all off-diagonal elements equal to 0.9 ###

y <- mvrnormixt(n,d,p=0.5,mu1=0,rho1=0.9,mu2=0,rho2=0)

p.value.BB(y)

