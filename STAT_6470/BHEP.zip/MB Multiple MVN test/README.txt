

The function p.value.MB(y) (see the file  pvalueMB_evaluation.R), where y (array of n lines and d columns) is a sample of size n (n \geq 20) over R^d (2\leq d \leq 10), gives an approximation for the P-value of the multiple test procedure MB proposed in

C. Tenreiro (2011). An affine invariant multiple test procedure for assessing multivariate normality.
Computational Statistics and Data Analysis 55 (12), 1980-1992.
(http://dx.doi.org/10.1016/j.csda.2010.12.004)

This approximation is based on Monte Carlo estimates of the quantiles c_{n,h}(u_{n,\alpha}) for each one of the involved multivariate test statistics where we take n \in { 20, (5), 100, 110, (10), 200, 220, (20), 300, (50), 800, 900, 1000 } and \alpha varying on the grid { 0.0005, (0.0005), 0.15, 0.2, (0.05), 0.95 }.

50,000 simulations under the null hypothesis and the R function quantile(,type=7) were used for estimating the quantiles c_{n,h}(u) for u varying on a regular grid of size 0.0001 on the interval ]0,1[, and further 50,000 simulations were used for estimating the probabilities P_\phi(T_n(u)>0).

The quantile estimates c_{n,h}(u_{n,\alpha}) are in the files BS_MB.R, BK_MB.R, BS_MB.R, BL_MB.R. For sample sizes different from the previous ones with n < 1000 the P-value is obtained by interpolation. For n > 1000 the P-value approximation is based on the quantiles for n = 1000.


EXAMPLE

R functions needed (see file pvalueMB_evaluation.R):

MS.stat
MK.stat
BHEP.stat
p.value.MB


library(MASS)

### Mixture of two multivariate normal distributions ###

mvrnormixt = function(n,d,p,mu1,rho1,mu2,rho2)
{
 mean1 <- rep(mu1,d)
 covar1 <- matrix(rep(rho1,d^2),ncol=d,nrow=d)+diag(rep(1-rho1,d))
 mean2 <- rep(mu2,d)
 covar2 <- matrix(rep(rho2,d^2),ncol=d,nrow=d)+diag(rep(1-rho2,d))
 x1 <- mvrnorm(n,mean1,covar1)
 x2 <- mvrnorm(n,mean2,covar2)
 pp <- 1*(runif(n)<p)
 return(pp*x1+(1-pp)*x2)
}


### Data dimension and Sample size ###

d = 3
n = 60


### Standard normal distribution sample ###

y <- mvrnorm(n,rep(0,d),diag(1,nrow=d,ncol=d))

p.value.MB(y)

### Normal scale mixture p*N(0,B) + (1-p)*N(0,I) sample ###
### where B is a correlation matrix with all off-diagonal elements equal to 0.9 ###

y <- mvrnormixt(n,d,p=0.5,mu1=0,rho1=0.9,mu2=0,rho2=0)

p.value.MB(y)

